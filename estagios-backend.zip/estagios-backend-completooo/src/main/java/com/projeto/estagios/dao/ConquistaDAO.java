package com.projeto.estagios.dao;

import com.projeto.estagios.model.Conquista;
import org.springframework.data.repository.CrudRepository;

public interface ConquistaDAO extends CrudRepository<Conquista, Long> { }